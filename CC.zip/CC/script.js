document.addEventListener('DOMContentLoaded', function() {
    // Dark Mode Toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;
    
    // Check if dark mode is enabled from session
    if (sessionStorage.getItem('darkMode') === 'true') {
        body.classList.add('dark-mode');
        darkModeToggle.checked = true;
    }
    
    // Toggle dark mode
    darkModeToggle.addEventListener('change', function() {
        const isDarkMode = this.checked;
        
        // Update UI
        body.classList.toggle('dark-mode', isDarkMode);
        
        // Save preference in session
        sessionStorage.setItem('darkMode', isDarkMode);
    });
    
    // Form validation
    const amountInput = document.getElementById('amount');
    amountInput.addEventListener('input', function() {
        if (this.value < 0) {
            this.value = 0;
        }
    });
    
    // Form submission
    const currencyForm = document.getElementById('currencyForm');
    const resultContainer = document.getElementById('resultContainer');
    const conversionResult = document.getElementById('conversionResult');
    const conversionRate = document.getElementById('conversionRate');
    const conversionTime = document.getElementById('conversionTime');
    
    currencyForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const amount = document.getElementById('amount').value;
        const fromCurrency = document.getElementById('fromCurrency').value;
        const toCurrency = document.getElementById('toCurrency').value;
        
        if (!amount) {
            alert('Please enter an amount');
            return;
        }
        
        // Show loading state
        const submitBtn = currencyForm.querySelector('.btn');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Converting...';
        submitBtn.disabled = true;
        
        // Send AJAX request
        fetch('converter.php', {
            method: 'POST',
            body: JSON.stringify({
                amount: amount,
                fromCurrency: fromCurrency,
                toCurrency: toCurrency
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error: ' + data.error);
            } else {
                // Update result
                conversionResult.innerHTML = `${data.amount} ${data.fromCurrency} = <span class="fw-bold">${data.result.toFixed(2)}</span> ${data.toCurrency}`;
                conversionRate.textContent = `Rate: 1 ${data.fromCurrency} = ${data.rate.toFixed(4)} ${data.toCurrency}`;
                conversionTime.textContent = `Converted on: ${data.time}`;
                
                // Show result container
                resultContainer.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Conversion failed. Please try again.');
        })
        .finally(() => {
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        });
    });
});