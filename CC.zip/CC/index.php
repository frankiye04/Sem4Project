<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Currency Converter</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="<?php echo isset($_SESSION['dark_mode']) && $_SESSION['dark_mode'] ? 'dark-mode' : ''; ?>">
    <div class="container">
        <div class="converter-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h1 class="card-title">Currency Converter</h1>
                <div class="dark-mode-container">
                    <span class="dark-mode-label">Dark Mode</span>
                    <label class="switch">
                        <input type="checkbox" id="darkModeToggle" 
                               <?php echo isset($_SESSION['dark_mode']) && $_SESSION['dark_mode'] ? 'checked' : ''; ?>>
                        <span class="slider round"></span>
                    </label>
                </div>
            </div>
            
            <form id="currencyForm">
                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="number" step="0.01" class="form-control" id="amount" name="amount" placeholder="Enter value" required>
                </div>
                
                <div class="form-group">
                    <label for="fromCurrency">From Currency</label>
                    <select class="form-control" id="fromCurrency" name="fromCurrency" required>
                        <option value="USD">USD</option>
                        <option value="EUR">EUR</option>
                        <option value="GBP">GBP</option>
                        <option value="JPY">JPY</option>
                        <option value="CAD">CAD</option>
                        <option value="INR">INR</option>
                        <option value="SGD">SGD</option>
                        <option value="LKR">LKR</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="toCurrency">To Currency</label>
                    <select class="form-control" id="toCurrency" name="toCurrency" required>
                        <option value="EUR">EUR</option>
                        <option value="USD">USD</option>
                        <option value="GBP">GBP</option>
                        <option value="JPY">JPY</option>
                        <option value="CAD">CAD</option>
                        <option value="INR">INR</option>
                        <option value="SGD">SGD</option>
                        <option value="LKR">LKR</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Convert</button>
            </form>
            
            <div class="result mt-4" id="resultContainer" style="display: none;">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Conversion Result</h5>
                        <p class="card-text">
                            <span id="conversionResult"></span>
                        </p>
                        <small class="text-muted" id="conversionRate"></small>
                        <small class="text-muted d-block mt-2" id="conversionTime"></small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>