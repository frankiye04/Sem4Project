<?php
session_start();

// API Configuration
$api_key = 'd327a35815f42e105f1d2b14';
$api_url = 'https://v6.exchangerate-api.com/v6/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input values from JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    $amount = $input['amount'] ?? null;
    $fromCurrency = $input['fromCurrency'] ?? null;
    $toCurrency = $input['toCurrency'] ?? null;
    
    if (!$amount || !$fromCurrency || !$toCurrency) {
        echo json_encode(['error' => 'Invalid input values']);
        exit;
    }
    
    try {
        // Rest of your code remains the same
        // Get latest exchange rates
        $url = $api_url . $api_key . '/latest/' . $fromCurrency;
        $response = @file_get_contents($url);
        
        if ($response === false) {
            throw new Exception('Failed to connect to the API');
        }
        
        $data = json_decode($response, true);
        
        if (isset($data['error'])) {
            throw new Exception($data['error']);
        }
        
        if (!isset($data['conversion_rates'][$toCurrency])) {
            throw new Exception('Conversion rate not found for ' . $toCurrency);
        }
        
        // Calculate conversion
        $rate = $data['conversion_rates'][$toCurrency];
        $result = $amount * $rate;
        
        // Return result
        echo json_encode([
            'result' => $result,
            'rate' => $rate,
            'fromCurrency' => $fromCurrency,
            'toCurrency' => $toCurrency,
            'amount' => $amount,
            'time' => date('Y-m-d H:i:s')
        ]);
        
    } catch (Exception $e) {
        // Use static rates as fallback
        $staticRates = [
            'USD' => 1.0,
            'EUR' => 0.85,
            'GBP' => 0.73,
            'JPY' => 110.0,
            'CAD' => 1.25,
            'INR' => 75.0,
            'SGD' => 1.35,
            'LKR' => 200.0
        ];
        
        if (!isset($staticRates[$fromCurrency]) || !isset($staticRates[$toCurrency])) {
            echo json_encode(['error' => 'Currency not supported in fallback mode']);
            exit;
        }
        
        $rate = $staticRates[$toCurrency] / $staticRates[$fromCurrency];
        $result = $amount * $rate;
        
        // Return result
        echo json_encode([
            'result' => $result,
            'rate' => $rate,
            'fromCurrency' => $fromCurrency,
            'toCurrency' => $toCurrency,
            'amount' => $amount,
            'time' => date('Y-m-d H:i:s'),
            'error' => 'API Error: ' . $e->getMessage()
        ]);
    }
}
?>